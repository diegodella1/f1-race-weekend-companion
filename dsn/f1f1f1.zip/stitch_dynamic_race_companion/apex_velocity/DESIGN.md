---
name: Apex Velocity
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#eabcb4'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#b08780'
  outline-variant: '#5f3e39'
  surface-tint: '#ffb4a7'
  primary: '#ffb4a7'
  on-primary: '#670400'
  primary-container: '#ff553d'
  on-primary-container: '#5b0300'
  inverse-primary: '#be0e00'
  secondary: '#a5e7ff'
  on-secondary: '#003543'
  secondary-container: '#00d2ff'
  on-secondary-container: '#00566a'
  tertiary: '#c8c6c5'
  on-tertiary: '#313030'
  tertiary-container: '#929090'
  on-tertiary-container: '#2a2a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a7'
  on-primary-fixed: '#400200'
  on-primary-fixed-variant: '#910900'
  secondary-fixed: '#b6ebff'
  secondary-fixed-dim: '#47d6ff'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e60'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  headline-xl:
    fontFamily: Chivo
    fontSize: 48px
    fontWeight: '900'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Chivo
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Chivo
    fontSize: 24px
    fontWeight: '800'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: -0.05em
  data-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.0'
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for a high-performance F1 companion experience, prioritizing split-second legibility and visceral emotional engagement. The personality is aggressive, technical, and elite, mirroring the cockpit of a modern racing machine.

The aesthetic merges **Glassmorphism** with **High-Contrast / Bold** elements. It utilizes a pitch-black foundation to allow neon data visualizations to pop with maximum intensity. Surfaces should feel like high-tech head-up displays (HUDs), utilizing translucent layers and glowing accents to signify speed and precision. Carbon fiber textures are applied subtly to structural backgrounds to provide tactile depth without distracting from the data.

## Colors
This design system operates on an "Ultra Dark" palette. 
- **Primary (#FF1801):** Used exclusively for high-priority "Live" states, critical alerts, and the leader of the pack. It carries a subtle outer glow (0px 0px 8px) in active states.
- **Secondary (#00D2FF):** Dedicated to technical telemetry, sector times, and secondary interactive elements. 
- **Neutral (#000000):** The absolute base. All background containers use pure black to maximize OLED efficiency and contrast.
- **Tertiary (#1A1A1A):** Used for "Carbon" surfaces and card backgrounds to create subtle separation from the pitch-black base.

## Typography
Typography is split between **Chivo** for an aggressive, slanted racing feel in headings, and **JetBrains Mono** for all timing and telemetry data. 

- **Italicization:** All Headlines must be italicized to convey a sense of forward motion and speed.
- **Tabular Numerals:** JetBrains Mono is mandatory for timing screens (lap times, intervals, speeds) to prevent "jumping" text during live updates.
- **Accessibility:** For mobile, `headline-xl` scales down to 36px.

## Layout & Spacing
The layout follows a **4px baseline grid** to maintain technical rigor. 

- **Grid:** Use a 12-column fluid grid for desktop and a 4-column grid for mobile. 
- **Data Density:** Layouts should be high-density. Horizontal scrolling is permitted for telemetry charts and timing tables to preserve data integrity.
- **Safe Zones:** High-energy UI elements (like live "REC" indicators) should maintain a 24px safety margin from the screen edges to avoid visual clutter.

## Elevation & Depth
In an ultra-dark environment, depth is created through **luminance and blur** rather than traditional shadows.

- **Level 1 (Base):** Pitch black #000000.
- **Level 2 (Cards):** #1A1A1A with a 1px solid border at 10% white opacity.
- **Level 3 (Overlays):** Glassmorphism effect. Background blur of 20px, 40% opacity of the surface color, and a "glowing" top-left border stroke.
- **Glows:** Active status indicators use an outer glow (spread 4-12px) using the `primary` or `secondary` color values to simulate light emission from a dashboard.

## Shapes
Shapes are sharp and angular, reflecting aerodynamic precision. 
- **Standard Radius:** 4px (`rounded-sm`).
- **Accent Shapes:** Use 45-degree clipped corners for buttons or tabs to mimic automotive component design.
- **Progress Bars:** Use square ends (0px radius) for telemetry bars to emphasize a mechanical, "filled" feel.

## Components
- **Buttons:** Primary buttons use a solid #FF1801 fill with black text. Secondary buttons use a ghost style with a #00D2FF glow-border.
- **Telemetry Chips:** Small, monospaced labels with a subtle background tint of the secondary color.
- **Live Indicator:** A circular dot using #FF1801 with a continuous "pulse" animation (scale 1.0 to 1.2, opacity 1.0 to 0.4).
- **Timing Lists:** Alternating row highlights using #080808 for zebra-striping. The "Active Sector" is highlighted with a 2px left-border in Electric Blue.
- **Input Fields:** Minimalist under-line style. When focused, the underline glows Electric Blue.
- **Cards:** Utilize a subtle "Carbon Fiber" SVG pattern overlay at 5% opacity on top of the #1A1A1A background.
- **Progress Bars:** Dual-layered. The background track is dark grey, and the fill is a gradient from #00D2FF to a brighter cyan, indicating intensity.